#ifndef DEMO_H
#define DEMO_H


void initPUI();

void createInterface();


#endif
